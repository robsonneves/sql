Insert into TB_TEMPO_BLINDAGEM (ID_TEMPO_BLINDAGEM,DS_TEMPO_BLINDAGEM) values ('1','Blindagem de até 3 anos');
Insert into TB_TEMPO_BLINDAGEM (ID_TEMPO_BLINDAGEM,DS_TEMPO_BLINDAGEM) values ('2','Blindagem com mais de 3 anos');
